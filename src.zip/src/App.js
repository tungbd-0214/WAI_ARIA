import logo from "./logo.svg";
import "./App.css";
import BreadCrumb from "./components/BreadCrumb";
function App() {
  return <BreadCrumb />;
}

export default App;
